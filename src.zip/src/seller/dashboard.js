import { useState, useEffect } from "react";

const MyDashboard = () =>{

    return(
        <div className="container mt-4">
            <div className="row mb-5">
                <div className="col-lg-12">
                    <h1 className="text-center"> Seller Dashboard </h1>
                </div>
            </div>

            <div className="row text-center">
                <div className="col-lg-4 text-primary">
                    <i className="fa fa-suitcase fa-4x"></i>
                    <h4> Total Product  100 </h4>
                </div>

                <div className="col-lg-4 text-warning">
                    <i className="fa fa-headset fa-4x"></i>
                    <h4> Order Received 300 </h4>
                </div>

                <div className="col-lg-4 text-success">
                    <i className="fa fa-plus fa-4x"></i>
                    <h4> Add Product </h4>
                </div>
            </div>
        </div>
    )
}

export default MyDashboard;